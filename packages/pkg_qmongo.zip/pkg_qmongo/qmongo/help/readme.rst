Aggregation Pipeline Stages
----------------------------

1- project

    .. include:: project.rst

2- out

    .. include:: out.rst

3- match

    .. include:: match.rst

4- redact

    .. include:: redact.rst