from setuptools import setup
import qmongo
setup(
    name='qmongo',
    version=qmongo.get_version(),
    packages=['qmongo', 'qmongo.helpers'],
    url='',
    license='',
    author='nttlong',
    author_email='zugeliang2000@gmail.com',
    description=''
)
