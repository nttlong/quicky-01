import os
global ROOT_DIR
ROOT_DIR = os.getcwd()
from . import importer
importer.add_path([
    "packages",
    "packages/django",
    "packages/quicky",
    "apps/hrm",
    "apps"
])
global db_config
import json_from_file

from qmongo import database
db_config = json_from_file.load("db.json")
print(db_config)
from hrm import settings
settings.db = database.connect(db_config)
from quicky import tenancy
tenancy.set_schema("hrm")
print "OK"