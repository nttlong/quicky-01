from . import *
def load(file):

    import json
    import os
    data = {}
    DIR = os.path.dirname(__file__)
    print ("load config from file '{0}'".format(DIR + os.sep + file))
    with open(DIR + os.sep + file) as f:
        data = json.load(f)
    return data

