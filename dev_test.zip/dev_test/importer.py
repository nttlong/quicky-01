import os
import sys
global REPO
REPO = os.path.dirname(os.path.dirname(__file__))
def add_path(_path):
    if type(_path) is list:
        for x in _path:
            print ("add path '{0}'".format(REPO + os.sep + x.replace('/', os.sep)))
            sys.path.append(REPO + os.sep + x.replace('/', os.sep))
    else:
        sys.path.append(REPO+os.sep+_path.replace('/',os.sep))
def re_import(mdl_name):
    import sys
    ret = [x for x in sys.modules.keys() if x == mdl_name]
    if ret.__len__() ==0:
        print ("'{0}' was not found")
    else:
        import importlib
        importlib.reload(mdl_name)
def find_module(mdl_name):
    import sys
    ret = [x for x in sys.modules.keys() if x.__contains__(mdl_name)]
    for x in ret:
        print x